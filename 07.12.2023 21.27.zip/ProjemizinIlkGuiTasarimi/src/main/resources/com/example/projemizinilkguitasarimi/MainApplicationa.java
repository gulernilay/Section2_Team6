import com.google.gson.Gson;
import java.io.*;
import java.util.Scanner;

public class MainApplicationa {

    public static void main(String[] args) {
        Gson gson = new Gson();
        Scanner scanner = new Scanner(System.in);

        // Kullanıcıdan dosya adını al
        System.out.print("What is the course code?(For check is this created?) ");
        String fileName = scanner.nextLine();
        String filePath = fileName + ".json";

        if (fileExists(filePath)) {
            System.out.print("A file with the same name already exists. Do you want to edit? (yes/no): ");
            String editChoice = scanner.nextLine();

                if ("yes".equalsIgnoreCase(editChoice)) {
                // METE KOD BURAYA GELECEK.
                // Read and print the existing JSON
                /*CourseInformationx existingCourse = readJsonFile(filePath);
                System.out.println("Existing data:\n" + existingCourse);

                // Update the existing course
                CourseInformationx updatedCourse = createNewCourse();
                String updatedJson = gson.toJson(updatedCourse);

                // Write the updated JSON to the file
                writeJsonToFile(updatedJson, filePath);

                // Read and print the updated JSON
                CourseInformationx updatedFromJson = readJsonFile(filePath);
                System.out.println("Updated data:\n" + updatedFromJson);

                return;*/
            }
            else {
                System.out.println("Exiting without further changes.");
                return;
            }
        } else {
            // Add a new object with user input
            CourseInformationx updatedCourse = createNewCourse();
            String newJson = gson.toJson(updatedCourse);

            // Write the updated JSON to a new file
            String newFilePath = updatedCourse.getCode() + ".json";
            writeJsonToFile(newJson, newFilePath);

            // Read and print the updated JSON
            CourseInformationx updatedFromJson = readJsonFile(newFilePath);
            System.out.println("Updated data:\n" + updatedFromJson);
        }
    }

    private static CourseInformationx createNewCourse() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Course Code ");
        String code = scanner.nextLine();

        // Create a new CourseInformationx object
        CourseInformationx newCourse = new CourseInformationx();
        newCourse.setCourseName(code);

        // Populate other properties
        addNewCourse(newCourse);

        return newCourse;
    }

    private static boolean fileExists(String filePath) {
        File file = new File(filePath);
        return file.exists();
    }

    private static void addNewCourse(CourseInformationx course) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Course Name: ");
        course.setCourseName(scanner.nextLine());

        System.out.print("Course Code: ");
        course.setCode(scanner.nextLine());

        System.out.print("Theory Credits: ");
        course.setTheory(scanner.nextInt());

        System.out.print("Lab Credits: ");
        course.setLab(scanner.nextInt());

        System.out.print("Local Credits: ");
        course.setLocalCredits(scanner.nextInt());

        System.out.print("ECTS Credits: ");
        course.setEcts(scanner.nextInt());

        System.out.print("Season: ");
        course.setSeason(scanner.next());

        System.out.print("Prerequisites: ");
        scanner.nextLine(); // consume the newline character
        course.setPrerequisities(scanner.nextLine());

        System.out.print("Course Language: ");
        course.setCourseLanguage(scanner.nextLine());



    }

    private static CourseInformationx readJsonFile(String filePath) {
        try (FileReader fileReader = new FileReader(filePath)) {
            return new Gson().fromJson(fileReader, CourseInformationx.class);
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Creating a new object.");
            return new CourseInformationx();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void writeJsonToFile(String json, String filePath) {
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            fileWriter.write(json);
            System.out.println("JSON written to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
